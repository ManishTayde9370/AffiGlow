import React from 'react'

function UserLayout({children}) {
  return (
    <>
      {children}
    </>
  )
}

export default UserLayout